# ******************************************************************************
#  Copyright (c) 2021-2022. Kneron Inc. All rights reserved.                   *
# ******************************************************************************

from enum import Enum


class Const(Enum):
    """
    Kneron PLUS constant value.

    Attributes
    ----------
    MAX_CROP_BOX : int, default=4
        Maximum number of crop boxes.
    FD_MAX : int, default=10
        Maximum number of face detection bounding boxes.
    LAND_MARK_POINTS : int, default=5
        Number of land marks points.
    FR_FEAT_LENGTH : int, default=256
        The length of one feature map.
    YOLO_GOOD_BOX_MAX : int, default=500
        Maximum number of bounding boxes for Yolo models.
    APP_PADDING_BYTES : int, default=28
        Reserved padding bytes for C structure.
    KP_MAX_INPUT_NODE_COUNT : int, default=100
        Maximum number of the model input node (Note: The KL520, KL720, KL630 and KL730 only support maximum 5 input number.)
    MAX_MODEL_NUM_IN_NEF : int, default=16
        Maximum number of model in NEF file.
    CHANNEL_NUM_RGBA8888 : int, default=4
        channel number of image format KP_IMAGE_FORMAT_RGBA8888.
    CHANNEL_NUM_RAW8 : int, default=1
        channel number of image format KP_IMAGE_FORMAT_RAW8.
    CHANNEL_NUM_OTHER_FORMAT : int, default=2
        channel number of other image format (exclude: KP_IMAGE_FORMAT_RGBA8888, KP_IMAGE_FORMAT_RAW8).
    """

    MAX_CROP_BOX = 4
    FD_MAX = 10
    LAND_MARK_POINTS = 5
    FR_FEAT_LENGTH = 256
    YOLO_GOOD_BOX_MAX = 500

    APP_PADDING_BYTES = 28
    KP_MAX_INPUT_NODE_COUNT = 100
    MAX_MODEL_NUM_IN_NEF = 16

    CHANNEL_NUM_RGBA8888 = 4
    CHANNEL_NUM_RAW8 = 1
    CHANNEL_NUM_OTHER_FORMAT = 2