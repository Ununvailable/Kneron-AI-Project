# ******************************************************************************
#  Copyright (c) 2021-2022. Kneron Inc. All rights reserved.                   *
# ******************************************************************************

from .KPWrapper import KPWrapper
from .KPStructure import ModelNefDescriptorBuffer, InfFixedNodeOutputBuffer, InfFloatNodeOutputBuffer
import ctypes


class KPWrapperUtils:
    __KP_WRAPPER = KPWrapper()

    @staticmethod
    def release_fixed_node_output(inference_fixed_node_output_buff: ctypes.POINTER(InfFixedNodeOutputBuffer)):
        KPWrapperUtils.__KP_WRAPPER.LIB.kp_release_fixed_node_output(inference_fixed_node_output_buff)

    @staticmethod
    def release_float_node_output(inference_float_node_output_buff: ctypes.POINTER(InfFloatNodeOutputBuffer)):
        KPWrapperUtils.__KP_WRAPPER.LIB.kp_release_float_node_output(inference_float_node_output_buff)

    @staticmethod
    def c_free(pointer: int):
        KPWrapperUtils.__KP_WRAPPER.LIB.py_c_free(ctypes.byref(pointer))

    @staticmethod
    def disconnect_devices_by_address(device_group_address: int) -> int:
        return KPWrapperUtils.__KP_WRAPPER.LIB.kp_disconnect_devices(device_group_address)

    @staticmethod
    def release_model_nef_descriptor(model_nef_descriptor: ModelNefDescriptorBuffer) -> int:
        return KPWrapperUtils.__KP_WRAPPER.LIB.kp_release_model_nef_descriptor(ctypes.byref(model_nef_descriptor))
